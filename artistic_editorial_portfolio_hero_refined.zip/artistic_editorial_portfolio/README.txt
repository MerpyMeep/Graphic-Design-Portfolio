ARTISTIC EDITORIAL PORTFOLIO STARTER

Open index.html in a browser to preview the site.

To publish with GitHub Pages:
1. Create or open the repository you want to use.
2. Upload index.html, styles.css, script.js, and the complete assets folder.
3. In repository Settings > Pages, select the branch and root folder.
4. Save and wait for GitHub Pages to publish.

Before publishing:
- Replace the empty mailto link with your preferred professional email.
- Confirm the public display name and location line.
- Add the correct artist/source credit for the original character artwork in the Velina fan concept.
- Add your own process sketches/iterations to the After//Hours and Velina case studies where available.
- Review all project descriptions and metadata for accuracy.

This is a first-pass website structure using the artwork supplied in the portfolio archive. It is designed as a responsive single-page site; project detail sections are included below the main gallery.
